let Personaggi = [
    { "nome": "Leonardo Da Vinci", "sesso": "M", "professione": "Artista", "Dopo1900": "No", "nobel": "No},
    { "nome": "Einstein", "sesso": "M", "professione": "Scienziato", "Dopo1900": "No", "nobel": "Si" },
    { "nome": "Ada Loverace", "sesso": "F", "professione": "Matematico", "Dopo1900": "No", "nobel": "No" },
    { "nome": "Grace Hopper", "sesso": "F", "professione": "Matematico", "Dopo1900": "Si", "nobel": "No" },
    { "nome": "Eulero", "sesso": "M", "professione": "Matematico",  "Dopo1900": "No", "nobel": "No" },
    { "nome": "Rita Levi-Montalcini", "sesso": "F", "professione": "Scienziato", "Dopo1900": "Si, "nobel": "No""},
    { "nome": "Marie curie", "sesso": "F", "professione": "Scienziato",  "Dopo1900": "No, "nobel": "Si"},
    { "nome": "Frida Kahlo", "sesso": "F",  "professione": "Pittore", "Dopo1900": "Si", "nobel": "No" },
    { "nome": "Nikola Tesla", "sesso": "M", "professione": "Ingegnere", "Dopo1900": "No" , "nobel": "No" },
    { "nome": "Leonardo Fibonacci", "sesso": "M", "professione": "Matematico", "Dopo1900": "No", "nobel": "No" },
    { "nome": "Archimede", "sesso": "M", "professione": "Matematico", "Dopo1900": "No, "nobel": "No""},
    { "nome": "Vincent van Gogh", "sesso": "M",  "professione": "Pittore", "Dopo1900": "No", "nobel": "No" },
    { "nome": "Picasso",  "sesso": "M",  "professione": "Pittore",  "Dopo1900": "No" , "nobel": "No" },
    { "nome": "Raffaello Sanzio",  "sesso": "M", "professione": "Pittore", "Dopo1900": "No", "nobel": "No" },
    { "nome": "Michelangelo Buonarotti",  "sesso": "M",  "professione": "Pittore",  "Dopo1900": "No", "nobel": "No" },
    { "nome": "J. Robert Oppenheimer", "sesso": "M", "professione": "Matematico", "Dopo1900": "Si", "nobel": "No" },
    { "nome": "Galileo Galilei", "sesso": "M","professione": "Scienziato", "Dopo1900": "No", "nobel": "No" },
    { "nome": "Nicolò Copernico", "sesso": "M", "professione": "scienziato", "Dopo1900": "No, "nobel" : "No"},
    { "nome": "Stephen Hawking", "sesso": "M", "professione": "Scienziato",  "Dopo1900": "Si" , "nobel": "No" },
    { "nome": "Margherita Hack", "sesso": "F", "professione": "Scienziato", "Dopo1900": "Si", "nobel": "No" },
]

console.log('Personaggi :>> ', Personaggi);

function scelto(proprieta, valore, classeBtn, btnId) {
    for (let i = 0; i < Personaggi.length;) {
        if (Personaggi[i][proprieta] != valore)
            Personaggi.splice(i, 1)
        else
            i++
   , "nobel": "No" }

    const btns = document.getElementsByClassName(classeBtn);

    for (let i = 0; i < btns.length; i++) {
        btns[i].onclick = ""
    }

    console.log('Personaggi :>> ', Personaggi);

    colore_bottone(btnId, classeBtn)

    if (Personaggi.length == 1) {
        console.log("Il tuo personaggio è ", Personaggi[0].nome);
    }
}

function elimina(proprieta, valore, classeBtn, btnId) {
    for (let i = 0; i < Personaggi.length;) {
        if (Personaggi[i][proprieta] == valore)
            Personaggi.splice(i, 1)
        else
            i++
    }

    const btns = document.getElementsByClassName(classeBtn);

    for (let i = 0; i < btns.length; i++) {
        btns[i].onclick = ""
    }
    
    
    colore_bottone(btnId, classeBtn)

    console.log('Personaggi :>> ', Personaggi);
}
function colore_bottone(buttonId, buttonClass)
{
    const btn = document.querySelector("."+buttonClass+"#"+buttonId);
    btn.style.backgroundColor = "lightgreen"

}