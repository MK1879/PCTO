let Personaggi = [
    { "nome": "Leonardo Da Vinci", "sesso": "M", "professione": "Artista", "Dopo1900": "No" },
    { "nome": "Einstein", "sesso": "M", "professione": "Scienziato", "Dopo1900": "No" },
    { "nome": "Ada Loverace", "sesso": "F", "professione": "Matematico", "Dopo1900": "No" },
    { "nome": "Grace Hopper", "sesso": "F", "professione": "Matematico", "Dopo1900": "Si" },
    { "nome": "Eulero", "sesso": "M", "professione": "Matematico",  "Dopo1900": "No" },
    { "nome": "Rita Levi-Montalcini", "sesso": "F", "professione": "Scienziato", "Dopo1900": "Si"},
    { "nome": "Marie curie", "sesso": "F", "professione": "Scienziato",  "Dopo1900": "No"},
    { "nome": "Frida Kahlo", "sesso": "F",  "professione": "Pittore", "Dopo1900": "Si" },
    { "nome": "Nikola Tesla", "sesso": "M", "professione": "Ingegnere", "Dopo1900": "No"  },
    { "nome": "Leonardo Fibonacci", "sesso": "M", "professione": "Matematico", "Dopo1900": "No" },
    { "nome": "Archimede", "sesso": "M", "professione": "Matematico", "Dopo1900": "No"},
    { "nome": "Vincent van Gogh", "sesso": "M",  "professione": "Pittore", "Dopo1900": "No" },
    { "nome": "Picasso",  "sesso": "M",  "professione": "Pittore",  "Dopo1900": "No"  },
    { "nome": "Raffaello Sanzio",  "sesso": "M", "professione": "Pittore", "Dopo1900": "No" },
    { "nome": "Michelangelo Buonarotti",  "sesso": "M",  "professione": "Pittore",  "Dopo1900": "No" },
    { "nome": "J. Robert Oppenheimer", "sesso": "M", "professione": "Matematico", "Dopo1900": "Si" },
    { "nome": "Galileo Galilei", "sesso": "M","professione": "Scienziato", "Dopo1900": "No" },
    { "nome": "Nicolò Copernico", "sesso": "M", "professione": "scienziato", "Dopo1900": "No"},
    { "nome": "Stephen Hawking", "sesso": "M", "professione": "Scienziato",  "Dopo1900": "Si"  },
    { "nome": "Margherita Hack", "sesso": "F", "professione": "Scienziato", "Dopo1900": "Si" },
]

console.log('Personaggi :>> ', Personaggi);

function SI(proprieta, valore, classeBtn) {
    for (let i = 0; i < Personaggi.length;) {
        if (Personaggi[i][proprieta] != valore)
            Personaggi.splice(i, 1)
        else
            i++
    }

    const btns = document.getElementsByClassName(classeBtn);

    for (let i = 0; i < btns.length; i++) {
        btns[i].onclick = ""
    }

    console.log('Personaggi :>> ', Personaggi);

    if (Personaggi.length == 1) {
        console.log("Il tuo personaggio è ", Personaggi[0].nome);
    }
}

function NO(proprieta, valore, classeBtn) {
    for (let i = 0; i < Personaggi.length;) {

        if (Personaggi[i][proprieta] != valore)
            Personaggi.splice(i, 1)
        else
            i++;
    }

    const btns = document.getElementsByClassName(classeBtn);

    for (let i = 0; i < btns.length; i++) {
        btns[i].onclick = ""
    }

    console.log('Personaggi :>> ', Personaggi);

    if (Personaggi.length == 1) {
        console.log("Il tuo personaggio è ", Personaggi[0].nome);
    }

}

function elimina(proprieta, valore, classeBtn) {
    for (let i = 0; i < Personaggi.length;) {
        if (Personaggi[i][proprieta] == valore)
            Personaggi.splice(i, 1)
        else
            i++
    }

    const btns = document.getElementsByClassName(classeBtn);

    for (let i = 0; i < btns.length; i++) {
        btns[i].onclick = ""
    }


    console.log('Personaggi :>> ', Personaggi);
}