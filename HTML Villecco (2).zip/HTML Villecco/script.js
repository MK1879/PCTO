let Personaggi = [
    {
        "nome": "Leonardo Da Vinci",
        "sesso": "M",
        "professione": "Artista",
        "Dopo1900": "No"

    },
    {
        "nome": "Einstein",
        "sesso": "M",
        "professione": "Scienziato",
        "Dopo1900": "No"
    },
    {
        "nome": "Ada Loverace",
        "sesso": "F",
        "professione": "Matematico",
        "Dopo1900": "No"
    },
    {
        "nome": "Grace Hopper",
        "sesso": "F",
        "professione": "Matematico",
        "Dopo1900": "Si"
    },
    {
        "nome": "Eulero",
        "sesso": "M",
        "professione": "Matematico",
        "Dopo1900": "No"
    },
    {
        "nome": "Rita Levi-Montalcini",
        "sesso": "F",
        "professione": "Scienziato",
        "Dopo1900": "Si"
    },
    {
        "nome": "Marie curie",
        "sesso": "F",
        "professione": "Scienziato",
        "Dopo1900": "No"
    },
    {
        "nome": "Frida Calo",
        "sesso": "F",
        "professione": "Pittore",
        "Dopo1900": "Si"
    },
    {
        "nome": "Nikola Tesla",
        "sesso": "F",
        "professione": "Ingegnere",
        "Dopo1900": "No"
    },
    {
        "nome": "Leonardo Fibonacci",
        "sesso": "M",
        "professione": "Matematico",
        "Dopo1900": "No"
    },
    {
        "nome": "Archimede",
        "sesso": "M",
        "professione": "Matematico",
        "Dopo1900": "No"
    },
    {
        "nome": "Vincent van Gogh",
        "sesso": "M",
        "professione": "Pittore",
        "Dopo1900": "No"
    },
    {
        "nome": "Picasso",
        "sesso": "M",
        "professione": "Pittore",
        "Dopo1900": "No"
    },
    {
        "nome": "Raffaello Sanzio",
        "sesso": "M",
        "professione": "Pittore",
        "Dopo1900": "No"
    },
    {
        "nome": "Michelangelo Buonarotti",
        "sesso": "M",
        "professione": "Pittore",
        "Dopo1900": "No"
    },
    {
        "nome": "J. Robert Oppenheimer",
        "sesso": "M",
        "professione": "Matematico",
        "Dopo1900": "Si"
    },
    {
        "nome": "Galileo Galilei",
        "sesso": "M",
        "professione": "Scienziato",
        "Dopo1900": "No"
    },
    {
        "nome": "Nicolò Copernico",
        "sesso": "M",
        "professione": "scienziato",
        "Dopo1900": "No"
    },
    {
        "nome": "Charles Darwin",
        "sesso": "M",
        "professione": "Scienziato",
        "Dopo1900": "No"
    },
    {
        "nome": "Margherita Hack",
        "sesso": "F",
        "professione": "Scienziato",
        "Dopo1900": "Si"
    },
]

console.log('Personaggi :>> ', Personaggi);

function SI(proprieta, valore) 
{
    for (let i = 0; i < Personaggi.length;) {
        if (Personaggi[i][proprieta] != valore)
            Personaggi.splice(i, 1)
        else
            i++
    }
    
    console.log('Personaggi :>> ', Personaggi);
    
    if (Personaggi.length == 1) {
        console.log("Il tuo personaggio è ", Personaggi[0].nome);
    }
}

function NO(proprieta, valore) 
{
    for(let j = 0; j < Personaggi.length;) {
        
        if (Personaggi[j][proprieta] != valore)
            Personaggi.splice(j, 1)
        else
        j++
}
    console.log('Personaggi :>> ', Personaggi);
    if (Personaggi.length == 1) {
         console.log("Il tuo personaggio è ", Personaggi[0].nome);
}

}

function elimina(proprieta, valore) {
    for (let i = 0; i < Personaggi.length;) {
        if (Personaggi[i][proprieta] == valore)
            Personaggi.splice(i, 1)
        else
            i++
    }
    console.log('Personaggi :>> ', Personaggi);
}